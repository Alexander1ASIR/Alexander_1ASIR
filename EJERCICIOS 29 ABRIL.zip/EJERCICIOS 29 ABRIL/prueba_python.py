 import pandas as pd 

    nombres = ['ana', 'Luis', 'Pedro']
    edades = [25,30,35]
    datos = ('nombres': nombres, 'Edades': edades)
    df = pd.DataFrame(datos)
    df.to_excel("datos.xlsx", index=False)
    

